#include <stdio.h>
#include <stdbool.h>

	int rminit (int n)
	{
	int i[10];
	n = (n/(n+1)) + 11;
	i[n] = 6 + n;	
	n = n + 65536;
	i[n] = 0;
	return (i[n]);
		
	}
