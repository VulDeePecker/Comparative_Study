#include <stdio.h>
#include <string.h>

int main()
{
	char password[256];
	gets(password);

	if (strcmp(password,"68af404b513073584c4b6f22b6c63e6b")) 
		{
		printf("Incorrect Password!\n");
		return 0;
		}

	printf("Entering Diagnostic Mode...\n");
	return 1;
}



